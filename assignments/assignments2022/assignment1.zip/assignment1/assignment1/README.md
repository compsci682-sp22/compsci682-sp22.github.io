Details about this assignment can be found [on the course webpage](https://compsci682-fa18.github.io/assignments2018/assignment1/), under Assignment #1 of Fall 2018.
